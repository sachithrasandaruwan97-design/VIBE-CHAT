package com.example.vibechat

import android.os.Bundle
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.Firebase
import com.google.firebase.auth.*
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.Query
import java.util.UUID

data class ChatMessage(
    val senderId: String = "",
    val text: String = "",
    val createdAt: Long = 0L
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VibeChatApp(this) } }
    }
}

@Composable
fun VibeChatApp(activity: Activity) {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { Firebase.firestore }
    var phone by remember { mutableStateOf("+94") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Enter your phone number with country code.") }
    var recipient by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var chatId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val user = auth.currentUser

    fun sendOtp() {
        if (phone.length < 8) { status = "Enter a valid phone number, e.g. +9477xxxxxxx"; return }
        busy = true
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    auth.signInWithCredential(credential).addOnCompleteListener {
                        busy = false
                        status = if (it.isSuccessful) "Verified!" else (it.exception?.localizedMessage ?: "Sign-in failed")
                    }
                }
                override fun onVerificationFailed(e: FirebaseException) {
                    busy = false
                    status = e.localizedMessage ?: "OTP request failed"
                }
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    busy = false
                    verificationId = id
                    status = "OTP sent. Enter the 6-digit code."
                }
            }).build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyOtp() {
        val id = verificationId
        if (id == null || otp.length != 6) { status = "Enter the 6-digit OTP first."; return }
        busy = true
        auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp))
            .addOnCompleteListener { task ->
                busy = false
                status = if (task.isSuccessful) "Phone number verified!" else (task.exception?.localizedMessage ?: "Verification failed")
            }
    }

    fun openChat() {
        val current = auth.currentUser ?: return
        val otherPhone = recipient.trim()
        if (!otherPhone.startsWith("+") || otherPhone.length < 8) {
            status = "Recipient must include country code, e.g. +9477xxxxxxx"; return
        }
        db.collection("users").whereEqualTo("phone", otherPhone).limit(1).get()
            .addOnSuccessListener { result ->
                val other = result.documents.firstOrNull()
                if (other == null) { status = "That number has not registered in Vibe Chat yet."; return@addOnSuccessListener }
                val ids = listOf(current.uid, other.id).sorted()
                val id = ids.joinToString("_")
                chatId = id
                db.collection("chats").document(id).collection("messages")
                    .orderBy("createdAt", Query.Direction.ASCENDING)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) { status = error.localizedMessage ?: "Could not load messages"; return@addSnapshotListener }
                        messages = snapshot?.documents?.mapNotNull { it.toObject(ChatMessage::class.java) } ?: emptyList()
                    }
                status = "Chat opened."
            }
            .addOnFailureListener { status = it.localizedMessage ?: "Could not find user." }
    }

    fun sendMessage() {
        val current = auth.currentUser ?: return
        val id = chatId ?: return
        val body = message.trim()
        if (body.isEmpty()) return
        val data = mapOf("senderId" to current.uid, "text" to body, "createdAt" to System.currentTimeMillis())
        db.collection("chats").document(id).collection("messages").add(data)
            .addOnSuccessListener { message = "" }
            .addOnFailureListener { status = it.localizedMessage ?: "Message failed to send" }
    }

    LaunchedEffect(auth.currentUser?.uid) {
        auth.currentUser?.let { current ->
            db.collection("users").document(current.uid)
                .set(mapOf("phone" to current.phoneNumber, "uid" to current.uid))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("VIBE CHAT", style = MaterialTheme.typography.headlineMedium)
        Text(status, style = MaterialTheme.typography.bodySmall)
        if (auth.currentUser == null) {
            OutlinedTextField(phone, { phone = it }, label = { Text("Phone number (+9477...)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { sendOtp() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Send OTP") }
            verificationId?.let {
                OutlinedTextField(otp, { otp = it.filter(Char::isDigit).take(6) }, label = { Text("6-digit OTP") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { verifyOtp() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Verify & Register") }
            }
        } else {
            Text("Signed in: ${auth.currentUser?.phoneNumber ?: "account"}")
            OutlinedTextField(recipient, { recipient = it }, label = { Text("Recipient phone (+country code)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { openChat() }, modifier = Modifier.fillMaxWidth()) { Text("Open chat") }
            Divider()
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(messages) { item ->
                    Text("${if (item.senderId == auth.currentUser?.uid) "You" else "Them"}: ${item.text}", modifier = Modifier.padding(vertical = 6.dp))
                }
            }
            if (chatId != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(message, { message = it }, label = { Text("Message") }, modifier = Modifier.weight(1f))
                    Button(onClick = { sendMessage() }) { Text("Send") }
                }
            }
            TextButton(onClick = { auth.signOut(); verificationId = null; status = "Signed out." }) { Text("Sign out") }
        }
    }
}
