# Vibe Chat (Android starter)

A small Kotlin + Jetpack Compose starter with Firebase Phone Authentication and one-to-one Firestore text chat.

## Requirements
- Android Studio (current stable)
- JDK 17
- A Firebase project
- An Android device or emulator with Google Play services for phone authentication

## Firebase setup
1. Create a project at https://console.firebase.google.com/.
2. Add an Android app with package name `com.example.vibechat`.
3. Download `google-services.json` and put it in the `app/` directory.
4. In Firebase Authentication > Sign-in method, enable **Phone**.
5. In Project settings > Your apps, add your debug SHA-1 and SHA-256 fingerprints. You can find them in Android Studio's Gradle tool window under `Tasks > android > signingReport`.
6. Create a Cloud Firestore database.
7. For a quick development test only, start Firestore in test mode. Before public release, replace test rules with secure rules (see below).

## Run
1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Add your `app/google-services.json`.
4. Run on a real Android device. Enter a phone number in E.164 format, e.g. `+9477xxxxxxx`.
5. Enter the SMS code. Once registered, enter the other user's registered phone number to open a chat.

Firebase may restrict SMS sending by region, quota, or abuse checks. Use Firebase Authentication's fictional test phone numbers during development.

## Important limitations
This is a learning starter, not a production-ready WhatsApp clone. It currently supports phone OTP sign-in and text messages between registered users. It does not yet include group chats, media, calls, push notifications, read receipts, blocking/reporting, end-to-end encryption, or full user discovery. It stores phone numbers in Firestore, so do not publish without appropriate privacy disclosures and access controls.

## Firestore security rules
Do not deploy publicly with open/test rules. A production design should validate that a signed-in user is a participant in each chat, restrict user profile reads, and validate message sender IDs. The simple starter data model needs additional participant metadata and hardened rules before production use. Ask for a security-rules pass before launch.
